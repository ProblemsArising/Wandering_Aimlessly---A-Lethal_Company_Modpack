# Wandering Aimlessly
(If you see this under "join" in LC I'm playing vanilla)

## If you like funny and helpful mods...
This might be the modpack for you.

## Story Made By Me

You wake up on the ship, this is your daily life now. You pick a destination and buy a couple things before you "PULL THE LEVER KRONK!!!" The next thing you know, Fortunate Son is playing as you land the ship. As you exit the ship and look around, the SpaceX starship is landing while Du Hast (Rammstein) starts playing. You grab your stuff from the starship and find your way to the entrance of the long abandoned structure. As soon as you enter, you hear noises, awful scary noises, but then they go away and you FEEL safe. You explore the structure and come across a locked door, you try to open it... "OPEN DA NOOR," it doesn't budge. Luckily, you remember you brought a lockpick and use that on the door, only to find a padlock on the ground in a small room. You turn around to go back to the main entrance only to see a coilhead. You stare at it for as long as you can, but then realize... YOU'VE BEEN BLINKING THIS ENTIRE TIME... AND YOU CAN'T STOP. You quickly go inside the small room and shut the door, but the coilhead is still coming, slowly. You put the padlock on the door, only to lock it, locking yourself inside, but the coilhead on the other side. Regretting your decision to come here, you remember your motto "For the Company." You get up, look all the way down and back up telling yourself "I can do this!" Looking further inside the room you realize the room isn't small, there's just a bunch of steam. You wander and tumble around until you find the steam valve, you shut off the steam and look around. Looking around, there's a small button behind you, you decide it's best NOT to press it. You find a room with a weird glowy thingy. You scan it and see it's worth some value for the company. Do you grab it or not, you ask yourself. Meh, why not, whats the worst that could happen? You pull it out and get an increased radiation warning on your HUD, nearing the limits for your suit. An alarm goes off "REacTorE CoRE UNstaBlE" you turn around, drop the glowy thingy, and start sprinting. You run around a corner "Quandingle Dangle what's up guys" it's BIG BLACK AND REALLY MAD... you run... it starts chasing you, you jump over a mine as the alarm goes off again "ReaCToRe COrE uNSta..." BOOOM! The mine goes off sending shrapnel into your back, sending you to the floor. Dragging yourself up, you see the creature's body behind you dead. You wobble around barely able to walk tumbling into a red door labled "FIRE EXIT." You almost fall out the door "NuCLEar MeltDOwn IMminENt BRaCe fOr IMPact!" You try your best to run with metal sticking out your leg and shoulder, so close to your ship, a different siren goes off sending shivers down your very being. You look to see a sirenhead digging out of the ground, the ship starts taking off. You jump to just barely grab the ladder in time, a huge blast behind you almost sending you off the ladder. You PULL yourself UP dragging yourself on the ship watching the flames engulf everything. The Sirenhead dissappearing almost instantly as you're halfway crawled into the ship. Your legs outside the ship, your torso inside, you hear the ship's hydraulic doors and it's all over. Better luck next time...


## Changelog

### v1.0.0

Included ALL modpacks I originally installed. It took me AN HOUR AND A HALF to write that story, hope you like it!


### v1.1.0

Updated modpack to include alot more fun and take off one mod which caused issues with others: (StarshipDeliveryMod). Includes versions as of 12/15/24 MM/DD/Year.